#' Wais data set
#'
#' The data of Agresti (1990);54 elderly people completed a subtest of the Wechsler Adult Intelligence Scale (WAIS) resulting in a discrete score with range from 0 to 20.
#'
#'
#' @format A data frame with 54 rows and 2 variables:
#' \describe{
#'   \item{wais}{wais, Adult Intelligence Scale,a discrete score with range from 0 to 20}
#'   \item{senility}{senility,(binary variable) using the WAIS score}
#'   ...
#' }
#' @source \url{not found}
"wais.df"
