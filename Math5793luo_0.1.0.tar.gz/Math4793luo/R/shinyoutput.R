#' shiny output for bootstrapping
#'
#' @param b is a numeric list of a dataframe,which is the paremater we can to estimate
#'
#' @param a is a numeric list of a dataframe,which is a factor can be help to decide b
#'
#' @return summary of mcmc procedure and plots for results
#'
#' @examples
#' wais=wais.df;a=wais$wais;b=wais$senility;
#' print.CMA(a,b)
#' @export


output.shiny = function(a,b,... ){
  library(shiny)
  # this defines our page layout
  ui<- pageWithSidebar(
    headerPanel("qqplot example"),
    sidebarPanel(
      # a slider called 'lambda':
      sliderInput("lambda",
                  "Lambda value",
                  min = -2,
                  max = 2,
                  step=0.01,
                  value = 0)
    ),
    mainPanel(
      # the main panel is the plotted output from qqplot:
      plotOutput("qqPlot")
    )
  )

  server<- function(input, output) {
    # b-c transform
    bc.fn <- function(y, lambda) {
      if (abs(lambda) < 0.001)
        z <- log(y) else z <- (y^lambda - 1)/lambda
    }
    # initial data
    y = exp(rnorm(50))
    # here's the qqplot method:
    output$qqPlot <- reactivePlot(function() {
      z <- bc.fn(y, input$lambda)
      qqnorm(z, main = paste("lambda =", round(input$lambda, 2)))
    })
  }

  # Run the app ----
  shinyApp(ui = ui, server = server)

}

