#' Create chi-square values for a dataframe
#'
#'
#' This function will give the output for chi-square test and qq plot for a dataframe.
#' @param df dataframe with numeric columns
#' @param x numeric column in dtaframe
#'
#'
#' @return list variable and plots
#'
#' @examples
#' df=diamonds;x=df$carat;
#' myqqchivalue(df,x)
#'
#' @export

myqqchivalue=function(df,x){
x_s=sort(x)
j=1:length(x_s)
p=(j-1/2)/length(x_s)
q=qnorm(p,mean=mean(x_s),sd=sd(x_s))
plot=plot(x=q,y=x_s,main = "QQ plot",xlab = "q(j)",ylab = "x(j)")

library(s20x)
fit = lm(x_s~q)
normcheck(fit)
sum=summary(fit)
sum

cortest=cor.test(y=x_s,x=q)
cortest

obj=list(q=head(q),p=head(p),sum=sum,cortest=cortest)

class(obj)="CMA" #create a new class: chi-square and mcmc analysis
obj

}

