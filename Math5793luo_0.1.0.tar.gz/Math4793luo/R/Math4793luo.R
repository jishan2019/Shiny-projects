#' Math4793luo
#'
#' This package helps to build chi-square plot and mcmc mehod to analyze data with given dataframe.
#'
#' @docType package
#'
#' @author Jishan Luo
#'
#' @name Math4793luo
NULL
