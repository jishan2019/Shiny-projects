#' MCMC analysis for dataframe
#'
#' @param b is a numeric list of a dataframe,which is the paremater we can to estimate
#'
#' @param a is a numeric list of a dataframe,which is a factor can be help to decide b
#'
#' @return summary of mcmc procedure and plots for results
#'
#' @examples
#' wais=wais.df;a=wais$wais;b=wais$senility;
#' print.CMA(a,b)
#' @export


print.CMA = function(a,b,... ){

  ##output for MCMC
  library(rjags)
  ##create inputs for MCMC analysis
  dataList=list(a = a, b= b,n=length(a))
  fileNameRoot="outputfile" # For output file names.
  #Define the model:
  modelString = "
  model{
  for(i in 1:n)
  {
  b[i] ~ dbin(p[i],1)
  logit(p[i]) <- beta0 + beta1 * a[i]

  }
  beta0 ~ dnorm(0.0, 1.0E-6)
  beta1 ~ dnorm(0.0, 1.0E-6)
  }
  " # close quote for modelString
  writeLines( modelString , con="TEMPmodel.txt" )

  # Initialize the chains based on MLE of data.
  # Option: Use single initial value for all chains:
  initsList = list(beta0 = -5, beta1 = 0.01)
  # Run the chains:
  jagsModel = jags.model( file="TEMPmodel.txt" , data=dataList , inits=initsList ,
                          n.chains=3 , n.adapt=500 )
  list.samplers(jagsModel)

  update( jagsModel , n.iter=500 )
  codaSamples = coda.samples( jagsModel , variable.names=c("beta0", "beta1"),
                              n.iter=33340 )
  save( codaSamples , file=paste0(fileNameRoot,"Mcmc.Rdata") )

  sum=summary(codaSamples)

  library(ggmcmc)
  s = ggs(codaSamples)
  sd=ggs_density(s)

  gc=ggs_crosscorrelation(s)

  list(sum=sum,s=s,sd=sd,gc=gc)
}

